angular.module('dashboard', ['ui.router', 'ngSanitize', 'ngTouch', 'ngAnimate'])
    .config(function ($stateProvider, $urlRouterProvider) {
        $urlRouterProvider.otherwise('/home');
        $stateProvider
            .state('home', {
                url: '/home',
                templateUrl: 'templates/home.html',
                controller: 'homeController'
            })
            .state('myClients', {
                url: '/myClients',
                templateUrl: 'templates/myClients.html',
                controller: 'clientsController'
            })
            .state('allClients', {
                url: '/allClients',
                templateUrl: 'templates/allClients.html',
                controller: 'clientsController'
            })
            .state('reports', {
                url: '/reports',
                templateUrl: 'templates/reports.html',
                controller: 'reportsController'
            })
    })
    .run(function ($rootScope, $state) {
        $rootScope.$state = $state;
    });