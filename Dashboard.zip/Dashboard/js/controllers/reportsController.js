angular.module("dashboard")
    .controller("reportsController", function ($scope, $state, dashboardFactory, $rootScope, $location) {

    });