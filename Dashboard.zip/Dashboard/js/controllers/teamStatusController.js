angular.module("dashboard")
    .controller("teamStatusController", function ($scope, $state, dashboardFactory, $rootScope, $location) {

    }); 