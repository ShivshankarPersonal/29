angular.module("dashboard")
    .controller("monthlyProgressController", function ($scope, $state, dashboardFactory, $rootScope, $location) {

    });